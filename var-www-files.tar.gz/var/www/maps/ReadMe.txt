This folder will hold maps which have been created after 
the log file has rolled over.  The currently running log
file map is not displayed here, as that map is shown on 
the main screen.
